export default function AIPanel() {
  return (
    <div>
      <h3>🤖 AI Assistant</h3>
      <p>코드 분석 / 리팩터링 / 에러 설명 / 질문 기능 들어갈 자리.</p>
    </div>
  );
}
